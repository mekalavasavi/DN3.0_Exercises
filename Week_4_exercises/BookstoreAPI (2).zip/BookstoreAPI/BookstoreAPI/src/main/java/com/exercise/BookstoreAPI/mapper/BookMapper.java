// BookMapper.java
package com.exercise.BookstoreAPI.mapper;

import com.exercise.BookstoreAPI.dto.BookDTO;
import com.exercise.BookstoreAPI.model.Book;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface BookMapper {
    BookDTO toDTO(Book book);
    Book toEntity(BookDTO bookDTO);
}

