// CustomerDTO.java
package com.exercise.BookstoreAPI.dto;

public class CustomerDTO {
    private Long id;
    private String name;
    private String email;

    // Getters and setters
}

