-- Enable server output to display procedure outputs
SET SERVEROUTPUT ON;

-- Create tables
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    Name VARCHAR2(100),
    DOB DATE,
    Balance INT,
    LastModified DATE,
    IsVIP CHAR(1)
);

CREATE TABLE Accounts (
    AccountID INT PRIMARY KEY,
    CustomerID INT,
    AccountType VARCHAR2(20),
    Balance INT,
    LastModified DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Transactions (
    TransactionID INT PRIMARY KEY,
    AccountID INT,
    TransactionDate DATE,
    Amount INT,
    TransactionType VARCHAR2(10),
    FOREIGN KEY (AccountID) REFERENCES Accounts(AccountID)
);

CREATE TABLE Loans (
    LoanID INT PRIMARY KEY,
    CustomerID INT,
    LoanAmount INT,
    InterestRate INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    Name VARCHAR2(100),
    Position VARCHAR2(50),
    Salary INT,
    Department VARCHAR2(50),
    DepartmentID INT,
    HireDate DATE
);

-- Create ErrorLogs table for logging errors
CREATE TABLE ErrorLogs (
    ErrorID INT PRIMARY KEY,
    ErrorMessage VARCHAR2(255),
    ErrorDate DATE
);

-- Scripts for Sample Data Insertion

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (1, 'John Doe', TO_DATE('1963-05-15', 'YYYY-MM-DD'), 1000, SYSDATE);

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (2, 'Jane Smith', TO_DATE('1990-07-20', 'YYYY-MM-DD'), 1500, SYSDATE);

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (1, 1, 'Savings', 1000, SYSDATE);

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (2, 2, 'Checking', 1500, SYSDATE);

INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (1, 1, SYSDATE, 200, 'Deposit');

INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (2, 2, SYSDATE, 300, 'Withdrawal');

INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (1, 1, 5000, 5, SYSDATE, ADD_MONTHS(SYSDATE, 60));

INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (2, 2, 10000, 5, SYSDATE, SYSDATE+25);

INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
VALUES (1, 'Alice Johnson', 'Manager', 70000, 'HR', TO_DATE('2015-06-15', 'YYYY-MM-DD'));

INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
VALUES (2, 'Bob Brown', 'Developer', 60000, 'IT', TO_DATE('2017-03-20', 'YYYY-MM-DD'));

-- SCENARIO - 1
-- Procedures for Customer Management
CREATE OR REPLACE PROCEDURE RegisterCustomer(
    p_CustID IN INT, 
    p_FullName IN VARCHAR2, 
    p_BirthDate IN DATE, 
    p_InitialBalance IN DECIMAL
) AS
BEGIN
    -- Insert customer details into the Customers table
    INSERT INTO Customers (CustomerID, Name, DOB, Balance) 
    VALUES (p_CustID, p_FullName, p_BirthDate, p_InitialBalance);
    
    -- Create a new account for the customer
    INSERT INTO Accounts (CustomerID, Balance) 
    VALUES (p_CustID, p_InitialBalance);
END;
/

CREATE OR REPLACE PROCEDURE ModifyCustomerInfo(
    p_CustID IN INT, 
    p_FullName IN VARCHAR2, 
    p_BirthDate IN DATE
) AS
BEGIN
    -- Update customer information in the Customers table
    UPDATE Customers
    SET Name = p_FullName, DOB = p_BirthDate
    WHERE CustomerID = p_CustID;
END;
/

CREATE OR REPLACE FUNCTION RetrieveCustomerBalance(
    p_CustID IN INT
) 
RETURN DECIMAL IS
    l_balance DECIMAL(10, 2);
BEGIN
    -- Fetch the balance from the Accounts table
    SELECT Balance INTO l_balance
    FROM Accounts
    WHERE CustomerID = p_CustID;

    RETURN l_balance;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0; -- Return 0 if the customer has no account
END;
/

-- SCENARIO - 2
-- Procedures for Employee Management
CREATE OR REPLACE PROCEDURE OnboardEmployee(
    p_EmpID IN INT, 
    p_FullName IN VARCHAR2, 
    p_JobTitle IN VARCHAR2, 
    p_BaseSalary IN DECIMAL
) AS
BEGIN
    -- Insert employee details into the Employees table
    INSERT INTO Employees (EmployeeID, Name, Position, Salary) 
    VALUES (p_EmpID, p_FullName, p_JobTitle, p_BaseSalary);
END;
/

CREATE OR REPLACE PROCEDURE UpdateEmployeeInfo(
    p_EmpID IN INT, 
    p_FullName IN VARCHAR2, 
    p_JobTitle IN VARCHAR2, 
    p_BaseSalary IN DECIMAL
) AS
BEGIN
    -- Update employee information in the Employees table
    UPDATE Employees
    SET Name = p_FullName, Position = p_JobTitle, Salary = p_BaseSalary
    WHERE EmployeeID = p_EmpID;
END;
/

CREATE OR REPLACE FUNCTION ComputeAnnualSalary(
    p_EmpID IN INT
) 
RETURN DECIMAL IS
    l_annual_salary DECIMAL(10, 2);
BEGIN
    -- Calculate the annual salary for the employee
    SELECT Salary * 12 INTO l_annual_salary
    FROM Employees
    WHERE EmployeeID = p_EmpID;

    RETURN l_annual_salary;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0; -- Return 0 if the employee is not found
END;
/

-- SCENARIO - 3
-- Procedures for Account Operations
CREATE OR REPLACE PROCEDURE CreateAccount(
    p_CustID IN INT, 
    p_OpeningBalance IN DECIMAL
) AS
BEGIN
    -- Insert new account details into the Accounts table
    INSERT INTO Accounts (CustomerID, Balance) 
    VALUES (p_CustID, p_OpeningBalance);
END;
/

CREATE OR REPLACE PROCEDURE RemoveAccount(
    p_CustID IN INT
) AS
BEGIN
    -- Delete the account for the specified customer
    DELETE FROM Accounts
    WHERE CustomerID = p_CustID;
END;
/

CREATE OR REPLACE FUNCTION FetchTotalBalance(
    p_CustID IN INT
) 
RETURN DECIMAL IS
    l_total_balance DECIMAL(10, 2);
BEGIN
    -- Calculate the total balance across all accounts for the customer
    SELECT SUM(Balance) INTO l_total_balance
    FROM Accounts
    WHERE CustomerID = p_CustID;

    RETURN l_total_balance;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0; -- Return 0 if no accounts are found for the customer
END;
/
