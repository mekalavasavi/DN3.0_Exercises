-- Enable server output to view procedure results
SET SERVEROUTPUT ON;

-- Create tables
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    Name VARCHAR2(100),
    DOB DATE,
    Balance INT,
    LastModified DATE,
    IsVIP CHAR(1)
);

CREATE TABLE Accounts (
    AccountID INT PRIMARY KEY,
    CustomerID INT,
    AccountType VARCHAR2(20),
    Balance INT,
    LastModified DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Transactions (
    TransactionID INT PRIMARY KEY,
    AccountID INT,
    TransactionDate DATE,
    Amount INT,
    TransactionType VARCHAR2(10),
    FOREIGN KEY (AccountID) REFERENCES Accounts(AccountID)
);

CREATE TABLE Loans (
    LoanID INT PRIMARY KEY,
    CustomerID INT,
    LoanAmount INT,
    InterestRate INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    Name VARCHAR2(100),
    Position VARCHAR2(50),
    Salary INT,
    Department VARCHAR2(50),
    DepartmentID INT,
    HireDate DATE
);

-- Create ErrorLogs table for logging errors
CREATE TABLE ErrorLogs (
    ErrorID INT PRIMARY KEY,
    ErrorMessage VARCHAR2(255),
    ErrorDate DATE
);

-- Scripts for Sample Data Insertion

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (1, 'John Doe', TO_DATE('1963-05-15', 'YYYY-MM-DD'), 1000, SYSDATE);

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (2, 'Jane Smith', TO_DATE('1990-07-20', 'YYYY-MM-DD'), 1500, SYSDATE);

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (1, 1, 'Savings', 1000, SYSDATE);

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (2, 2, 'Checking', 1500, SYSDATE);

INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (1, 1, SYSDATE, 200, 'Deposit');

INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (2, 2, SYSDATE, 300, 'Withdrawal');

INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (1, 1, 5000, 5, SYSDATE, ADD_MONTHS(SYSDATE, 60));

INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (2, 2, 10000, 5, SYSDATE, SYSDATE+25);

INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
VALUES (1, 'Alice Johnson', 'Manager', 70000, 'HR', TO_DATE('2015-06-15', 'YYYY-MM-DD'));

INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
VALUES (2, 'Bob Brown', 'Developer', 60000, 'IT', TO_DATE('2017-03-20', 'YYYY-MM-DD'));

-- Scenario 1: Generate Monthly Reports for Each Customer
CREATE OR REPLACE PROCEDURE GenerateMonthlyReports AS
    -- Define cursor and variables to retrieve transaction details
    CURSOR cur_monthly_reports IS
        SELECT acc.CustomerID, trans.TransactionDate, trans.Amount
        FROM Transactions trans
        JOIN Accounts acc ON trans.AccountID = acc.AccountID
        WHERE EXTRACT(MONTH FROM trans.TransactionDate) = EXTRACT(MONTH FROM SYSDATE)
          AND EXTRACT(YEAR FROM trans.TransactionDate) = EXTRACT(YEAR FROM SYSDATE);

    l_customer_id INT;
    l_transaction_date DATE;
    l_amount DECIMAL(10, 2);
BEGIN
    -- Iterate over the cursor to process each transaction
    FOR rec_monthly_report IN cur_monthly_reports LOOP
        l_customer_id := rec_monthly_report.CustomerID;
        l_transaction_date := rec_monthly_report.TransactionDate;
        l_amount := rec_monthly_report.Amount;

        -- Output the transaction details (this can be modified to insert into another table or generate a file)
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || l_customer_id || 
                             ', Transaction Date: ' || l_transaction_date || 
                             ', Transaction Amount: ' || l_amount);
    END LOOP;
END;
/

-- SHOW ERRORS PROCEDURE GenerateMonthlyReports;

-- Scenario 2: Deduct Annual Maintenance Fee from Each Account
CREATE OR REPLACE PROCEDURE DeductAnnualFee AS
    -- Define cursor and variables to access account balances
    CURSOR cur_accounts IS
        SELECT AccountID, Balance
        FROM Accounts;

    l_account_id INT;
    l_balance DECIMAL(10, 2);
    l_annual_fee DECIMAL(10, 2) := 45.00;  -- Set the annual fee amount
BEGIN
    -- Iterate over the cursor to apply the annual fee to each account
    FOR rec_account IN cur_accounts LOOP
        l_account_id := rec_account.AccountID;
        l_balance := rec_account.Balance;

        -- Subtract the annual fee from the account's balance
        UPDATE Accounts
        SET Balance = l_balance - l_annual_fee
        WHERE AccountID = l_account_id;

        -- Output the account details after fee deduction
        DBMS_OUTPUT.PUT_LINE('Account ID: ' || l_account_id || ' - maintanence fee for annual deducted');
    END LOOP;
END;
/

-- Scenario 3: Adjust Loan Interest Rates According to Updated Policy
CREATE OR REPLACE PROCEDURE AdjustLoanInterestRates AS
    -- Define cursor and variables to update interest rates on loans
    CURSOR cur_loans IS
        SELECT LoanID, InterestRate
        FROM Loans;

    l_loan_id INT;
    l_current_rate DECIMAL(5, 2);
    l_new_rate DECIMAL(5, 2);
BEGIN
    -- Iterate over the cursor to apply new interest rates
    FOR rec_loan IN cur_loans LOOP
        l_loan_id := rec_loan.LoanID;
        l_current_rate := rec_loan.InterestRate;

        -- Calculate the new interest rate based on policy (e.g., a 4% increase)
        l_new_rate := l_current_rate * 1.04;

        -- Update the loan with the new interest rate
        UPDATE Loans
        SET InterestRate = l_new_rate
        WHERE LoanID = l_loan_id;

        -- Output the loan details after interest rate adjustment
        DBMS_OUTPUT.PUT_LINE('Loan ID: ' || l_loan_id || ' - Interest rate adjusted to: ' || l_new_rate);
    END LOOP;
END;
/

-- Execute the procedures to test their functionality
BEGIN
    GenerateMonthlyReports;
END;
/

BEGIN
    DeductAnnualFee;
END;
/

BEGIN
    AdjustLoanInterestRates;
END;
/
