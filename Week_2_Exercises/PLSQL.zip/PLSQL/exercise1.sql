-- Exercise 1: Creating Tables

-- Table to store customer details
CREATE TABLE Customers (
    CustomerID NUMBER PRIMARY KEY,  -- Unique identifier for each customer
    Name VARCHAR2(100),             -- Customer's full name
    DOB DATE,                       -- Customer's date of birth
    Balance NUMBER,                -- Total account balance of the customer
    LastModified DATE              -- Date when the customer record was last updated
);

-- Table to store account details linked to customers
CREATE TABLE Accounts (
    AccountID NUMBER PRIMARY KEY,   -- Unique identifier for each account
    CustomerID NUMBER,              -- Reference to the owning customer
    AccountType VARCHAR2(20),      -- Type of account (e.g., Savings, Checking)
    Balance NUMBER,                -- Current balance of the account
    LastModified DATE,              -- Date when the account record was last updated
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID) -- Foreign key relationship
);

-- Table for recording transactions linked to accounts
CREATE TABLE Transactions (
    TransactionID NUMBER PRIMARY KEY,  -- Unique identifier for each transaction
    AccountID NUMBER,                  -- Reference to the related account
    TransactionDate DATE,              -- Date when the transaction occurred
    Amount NUMBER,                    -- Amount of the transaction
    TransactionType VARCHAR2(10),     -- Type of transaction (e.g., Deposit, Withdrawal)
    FOREIGN KEY (AccountID) REFERENCES Accounts(AccountID) -- Foreign key relationship
);

-- Table for tracking loans provided to customers
CREATE TABLE Loans (
    LoanID NUMBER PRIMARY KEY,         -- Unique identifier for each loan
    CustomerID NUMBER,                -- Reference to the customer who took the loan
    LoanAmount NUMBER,                -- Amount of the loan
    InterestRate NUMBER,              -- Interest rate applied to the loan
    StartDate DATE,                   -- Start date of the loan
    EndDate DATE,                     -- End date of the loan
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID) -- Foreign key relationship
);

-- Table to store employee information
CREATE TABLE Employees (
    EmployeeID NUMBER PRIMARY KEY,     -- Unique identifier for each employee
    Name VARCHAR2(100),                -- Employee's full name
    Position VARCHAR2(50),             -- Employee's job title
    Salary NUMBER,                     -- Employee's salary
    Department VARCHAR2(50),           -- Department where the employee works
    HireDate DATE                      -- Date when the employee was hired
);

-- Insert sample data into Customers
INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (1, 'John Doe', TO_DATE('1963-05-15', 'YYYY-MM-DD'), 1000, SYSDATE);

-- Insert sample data into Accounts
INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (1, 1, 'Savings', 1000, SYSDATE);

-- Insert sample data into Transactions
INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (1, 1, SYSDATE, 200, 'Deposit');

-- Insert sample data into Loans
INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (1, 1, 5000, 5, SYSDATE, ADD_MONTHS(SYSDATE, 60));

-- Insert sample data into Employees
INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
VALUES (1, 'Alice Johnson', 'Manager', 70000, 'HR', TO_DATE('2015-06-15', 'YYYY-MM-DD'));

-- Enable server output to view procedure execution results
SET SERVEROUTPUT ON;

-- Add IsVIP column to Customers table to track VIP status
ALTER TABLE Customers ADD IsVIP CHAR(1);

-- Procedure to apply a 1% discount on interest rates for customers older than 60
CREATE OR REPLACE PROCEDURE ApplyInterestDiscount IS
    CURSOR custCursor IS
        SELECT CustomerID, DOB FROM Customers;
    
    custID Customers.CustomerID%TYPE;
    custDOB Customers.DOB%TYPE;
    today DATE := SYSDATE;
BEGIN
    FOR custRec IN custCursor LOOP
        IF MONTHS_BETWEEN(today, custRec.DOB) / 12 > 60 THEN
            UPDATE Loans
            SET InterestRate = InterestRate * 0.99
            WHERE CustomerID = custRec.CustomerID;
            DBMS_OUTPUT.PUT_LINE('scenario1');
        END IF;
    END LOOP;
END ApplyInterestDiscount;
/

-- Procedure to update VIP status based on account balance
CREATE OR REPLACE PROCEDURE PromoteToVIP IS
    CURSOR accCursor IS
        SELECT CustomerID, Balance FROM Accounts;
    
    accID Accounts.CustomerID%TYPE;
    accBalance Accounts.Balance%TYPE;
BEGIN
    FOR accRec IN accCursor LOOP
        IF accRec.Balance > 5000 THEN
            UPDATE Customers
            SET IsVIP = 'Y'
            WHERE CustomerID = accRec.CustomerID;
            
        ELSE
            UPDATE Customers
            SET IsVIP = 'N'
            WHERE CustomerID = accRec.CustomerID;
            DBMS_OUTPUT.PUT_LINE('scenario2');
        END IF;
    END LOOP;
END PromoteToVIP;
/

-- Procedure to send reminders for loans due within the next 30 days
CREATE OR REPLACE PROCEDURE SendLoanReminders IS
    CURSOR loanCursor IS
        SELECT CustomerID, EndDate 
        FROM Loans 
        WHERE EndDate BETWEEN SYSDATE AND SYSDATE + 30;
    
    loanID Loans.CustomerID%TYPE;
    loanEnd Loans.EndDate%TYPE;
BEGIN
    FOR loanRec IN loanCursor LOOP
        DBMS_OUTPUT.PUT_LINE('scenario3');
    END LOOP;
END SendLoanReminders;
/

-- Execute the procedures to apply interest discount, update VIP status, and send loan reminders
BEGIN
    DBMS_OUTPUT.PUT_LINE('SCENARIO - 1 has successfully executed');
    ApplyInterestDiscount; -- Execute procedure to apply discount on interest rates
END;
/
BEGIN
    DBMS_OUTPUT.PUT_LINE('SCENARIO - 2 has successfully executed');
    PromoteToVIP; -- Execute procedure to update VIP status based on account balance
END;
/
BEGIN
    DBMS_OUTPUT.PUT_LINE('SCENARIO - 3 has successfully executed');
    SendLoanReminders; -- Execute procedure to send reminders for upcoming loan due dates
END;
/
