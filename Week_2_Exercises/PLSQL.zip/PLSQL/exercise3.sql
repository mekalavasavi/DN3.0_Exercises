-- Enable server output
SET SERVEROUTPUT ON;

-- Create tables
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    FullName VARCHAR2(100),
    DateOfBirth DATE,
    AccountBalance INT,
    LastUpdate DATE,
    VIPStatus CHAR(1)
);

CREATE TABLE Accounts (
    AccountID INT PRIMARY KEY,
    CustomerID INT,
    TypeOfAccount VARCHAR2(20),
    AccountBalance INT,
    LastUpdate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Transactions (
    TransactionID INT PRIMARY KEY,
    AccountID INT,
    DateOfTransaction DATE,
    Amount INT,
    TypeOfTransaction VARCHAR2(10),
    FOREIGN KEY (AccountID) REFERENCES Accounts(AccountID)
);

CREATE TABLE Loans (
    LoanID INT PRIMARY KEY,
    CustomerID INT,
    Amount INT,
    InterestRate INT,
    LoanStartDate DATE,
    LoanEndDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FullName VARCHAR2(100),
    JobTitle VARCHAR2(50),
    SalaryAmount INT,
    DeptName VARCHAR2(50),
    DeptID INT,
    DateHired DATE
);

-- Create ErrorLogs table for logging errors
CREATE TABLE ErrorLogs (
    LogID INT PRIMARY KEY,
    Message VARCHAR2(255),
    LogDate DATE
);

-- Insert sample data into Customers
INSERT INTO Customers (CustomerID, FullName, DateOfBirth, AccountBalance, LastUpdate)
VALUES (1, 'John Doe', TO_DATE('1963-05-15', 'YYYY-MM-DD'), 1000, SYSDATE);

INSERT INTO Customers (CustomerID, FullName, DateOfBirth, AccountBalance, LastUpdate)
VALUES (2, 'Jane Smith', TO_DATE('1990-07-20', 'YYYY-MM-DD'), 1500, SYSDATE);

-- Insert sample data into Accounts
INSERT INTO Accounts (AccountID, CustomerID, TypeOfAccount, AccountBalance, LastUpdate)
VALUES (1, 1, 'Savings', 1000, SYSDATE);

INSERT INTO Accounts (AccountID, CustomerID, TypeOfAccount, AccountBalance, LastUpdate)
VALUES (2, 2, 'Checking', 1500, SYSDATE);

-- Insert sample data into Transactions
INSERT INTO Transactions (TransactionID, AccountID, DateOfTransaction, Amount, TypeOfTransaction)
VALUES (1, 1, SYSDATE, 200, 'Deposit');

INSERT INTO Transactions (TransactionID, AccountID, DateOfTransaction, Amount, TypeOfTransaction)
VALUES (2, 2, SYSDATE, 300, 'Withdrawal');

-- Insert sample data into Loans
INSERT INTO Loans (LoanID, CustomerID, Amount, InterestRate, LoanStartDate, LoanEndDate)
VALUES (1, 1, 5000, 5, SYSDATE, ADD_MONTHS(SYSDATE, 60));

INSERT INTO Loans (LoanID, CustomerID, Amount, InterestRate, LoanStartDate, LoanEndDate)
VALUES (2, 2, 10000, 5, SYSDATE, SYSDATE + 25);

-- Insert sample data into Employees
INSERT INTO Employees (EmployeeID, FullName, JobTitle, SalaryAmount, DeptName, DateHired)
VALUES (1, 'Alice Johnson', 'Manager', 70000, 'HR', TO_DATE('2015-06-15', 'YYYY-MM-DD'));

INSERT INTO Employees (EmployeeID, FullName, JobTitle, SalaryAmount, DeptName, DateHired)
VALUES (2, 'Bob Brown', 'Developer', 60000, 'IT', TO_DATE('2017-03-20', 'YYYY-MM-DD'));

-- Procedure to Apply Monthly Interest to Savings Accounts
CREATE OR REPLACE PROCEDURE ApplyMonthlyInterest IS
    updatedRows NUMBER;
BEGIN
    UPDATE Accounts
    SET AccountBalance = AccountBalance * 1.01
    WHERE TypeOfAccount = 'Savings';

    updatedRows := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('No.of accounts that have been updated are: ' || updatedRows);
    DBMS_OUTPUT.PUT_LINE('Successfully updated');
END ApplyMonthlyInterest;
/

-- Procedure to Update Employee Bonus Based on Department
CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus(
    deptID IN INT,
    bonusPercentage IN DECIMAL
) IS
BEGIN
    UPDATE Employees
    SET SalaryAmount = SalaryAmount + (SalaryAmount * (bonusPercentage / 100))
    WHERE DeptID = deptID;
END UpdateEmployeeBonus;
/

-- Procedure to Transfer Funds Between Accounts
CREATE OR REPLACE PROCEDURE TransferFunds(
    srcAccID IN INT,
    destAccID IN INT,
    amount IN DECIMAL
) IS
BEGIN
    DECLARE
        noFunds EXCEPTION;
        PRAGMA EXCEPTION_INIT(noFunds, -20001);

    BEGIN
        SAVEPOINT start_trans;

        DECLARE
            currentBalance INT;
        BEGIN
            SELECT AccountBalance INTO currentBalance
            FROM Accounts
            WHERE AccountID = srcAccID;
            
            IF currentBalance < amount THEN
                RAISE noFunds;
            END IF;
        END;

        UPDATE Accounts
        SET AccountBalance = AccountBalance - amount
        WHERE AccountID = srcAccID;

        UPDATE Accounts
        SET AccountBalance = AccountBalance + amount
        WHERE AccountID = destAccID;

        COMMIT;
    EXCEPTION
        WHEN noFunds THEN
            INSERT INTO ErrorLogs (Message, LogDate)
            VALUES ('Insufficient funds for AccountID: ' || srcAccID, SYSDATE);
            ROLLBACK TO start_trans;
        WHEN OTHERS THEN
            INSERT INTO ErrorLogs (Message, LogDate)
            VALUES ('Error during transfer from AccountID: ' || srcAccID || ' to AccountID: ' || destAccID, SYSDATE);
            ROLLBACK TO start_trans;
    END;
END TransferFunds;
/

-- Example calls for the procedures
BEGIN
    ApplyMonthlyInterest;
END;
/

BEGIN
    UpdateEmployeeBonus(1, 10.00);
END;
/

BEGIN
    TransferFunds(1, 2, 100.00);
END;
/
